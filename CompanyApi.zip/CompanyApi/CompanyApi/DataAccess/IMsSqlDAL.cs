﻿using CompanyClasses;

namespace CompanyApi.DataAccess
{
    public interface IMsSqlDAL
    {
        List<Company> GetCompanies();
        string AddCompany(Company company);
        Company GetCompanyByIsin(string isin);
        Company GetCompanyById(int id);
        (bool, string) UpdateCompany(Company company);
    }
}
