﻿using AutoMapper;
using CompanyApi.Models;
using CompanyApi.Services;
using CompanyApi.Validators;
using CompanyClasses;
using Microsoft.AspNetCore.Mvc;

namespace CompanyApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyController : Controller
    {
        private readonly ICompanyServices _companyService;
        private readonly IMapper _mapper;

        public CompanyController(ICompanyServices companyService, IMapper mapper)
        {
            _companyService = companyService;
            _mapper = mapper;
        }

        [HttpGet]
        [Route("getCompanies")]
        public List<Company> GetCompanies()
        {
            return _companyService.GetCompanies();           
        }

        [HttpPost]
        [Route("addCompany")]
        public IActionResult AddCompany([FromBody] CompanyInsertDTO companyDto)
        {
            var companyValidator = new CompanyInsertValidator();
            var result = companyValidator.Validate(companyDto);
            if (result.IsValid)
            {
                Company company = _mapper.Map<CompanyInsertDTO, Company>(companyDto);
                string addResult = _companyService.AddCompany(company);

                if (int.TryParse(addResult, out _))
                    return Ok(addResult);
                else
                    return BadRequest(addResult);
            }
            var errorMessages = result.Errors.Select(x => x.ErrorMessage).ToList();
            return BadRequest(errorMessages);           
        }

        [HttpGet]
        [Route("getCompanyByIsin/{isin}")]
        public IActionResult GetCompanyByIsin(string isin)
        {
            if (string.IsNullOrEmpty(isin))
                return BadRequest("Isin is required");
            return Ok(_companyService.GetCompanyByIsin(isin));           
        }

        [HttpGet]
        [Route("getCompanyById/{id}")]
        public IActionResult GetCompanyById(int id)
        {
            if (id > 0)
                return Ok(_companyService.GetCompanyById(id));
            else
                return BadRequest("Id is required");            
        }

        [HttpPut]
        [Route("updateCompany")]
        public IActionResult UpdateCompany([FromBody] CompanyUpdateDTO companyDTO)
        {
            var companyValidator = new CompanyUpdatetValidator();
            var result = companyValidator.Validate(companyDTO);
            if (result.IsValid)
            {
                Company company = _mapper.Map<CompanyUpdateDTO, Company>(companyDTO);
                var updateResult = _companyService.UpdateCompany(company);

                if (updateResult.Item1)
                    return Ok(updateResult.Item2);
                else
                    return BadRequest(updateResult.Item2);
            }
            var errorMessages = result.Errors.Select(x => x.ErrorMessage).ToList();
            return BadRequest(errorMessages);           
        }
    }
}
