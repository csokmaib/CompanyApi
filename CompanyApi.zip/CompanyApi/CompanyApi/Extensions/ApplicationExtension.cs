﻿using CompanyApi.DataAccess;
using CompanyApi.Services;

namespace CompanyApi.Extensions
{
    public static class ApplicationExtension
    {
        public static void AddDBFactories(this IServiceCollection services)
        {
            services
                .AddSingleton<IMsSqlDAL, MsSqlDAL>();
        }

        public static void AddServices(this IServiceCollection services)
           => services
           .AddSingleton<ICompanyServices, CompanyServices>();
    }
}
