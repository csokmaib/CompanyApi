﻿using CompanyApi.Options;
using CompanyClasses;
using CompanyDataAccess;
using Microsoft.Extensions.Options;

namespace CompanyApi.DataAccess
{
    public class MsSqlDAL: IMsSqlDAL
    {
        private readonly MsSqlDataAccess _dbAccess;

        public MsSqlDAL(IOptions<DBConnectionOptions> options)
        {
            _dbAccess = new MsSqlDataAccess(options.Value.MsSqlConnection);
        }

        public List<Company> GetCompanies()
        {
            return _dbAccess.GetCompanies();
        }

        public string AddCompany(Company company)
        {
            return _dbAccess.AddCompany(company);
        }

        public Company GetCompanyByIsin(string isin)
        {
            return _dbAccess.GetCompanyByIsin(isin);
        }

        public Company GetCompanyById(int id)
        {
            return _dbAccess.GetCompanyById(id);
        }

        public (bool, string) UpdateCompany(Company company)
        {
            return _dbAccess.UpdateCompany(company);
        }
    }
}
