﻿using CompanyApi.Options;
using Microsoft.Extensions.Options;

namespace CompanyApi.Configurations
{
    public class DBConnectionConfiguration : IConfigureOptions<DBConnectionOptions>
    {
        private readonly IConfiguration _configuration;

        public DBConnectionConfiguration(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        public void Configure(DBConnectionOptions options)
        {
            _configuration.GetSection(DBConnectionOptions.DBConnectionOptionsSection).Bind(options);
        }
    }
}
