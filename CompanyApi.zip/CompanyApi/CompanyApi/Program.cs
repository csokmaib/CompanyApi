using CompanyApi.Configurations;
using CompanyApi.Extensions;
using CompanyApi.Middlewares;
using FluentValidation.AspNetCore;
using NLog;

var logger = LogManager.Setup().LoadConfigurationFromFile("nlog.config").GetCurrentClassLogger();
logger.Debug("Initlializing application");

try
{
    var builder = WebApplication.CreateBuilder(args);

    // Add services to the container.

    builder.Services.ConfigureOptions<DBConnectionConfiguration>();
    builder.Services.AddServices();
    builder.Services.AddDBFactories();
    builder.Services.AddFluentValidationAutoValidation();
    builder.Services.AddAutoMapper(typeof(Program));

    builder.Services.AddControllers();
    // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
    builder.Services.AddEndpointsApiExplorer();
    builder.Services.AddSwaggerGen();

    var app = builder.Build();

    app.UseMiddleware<ExceptionHandlerMiddleware>();

    // Configure the HTTP request pipeline.
    if (app.Environment.IsDevelopment())
    {
        app.UseSwagger();
        app.UseSwaggerUI();
    }

    app.UseHttpsRedirection();

    app.UseAuthorization();

    app.MapControllers();

    app.Run();
}
catch (Exception ex)
{
    logger.Error(ex, "Host terminated unespectedly");
    throw;
}
finally
{
    LogManager.Shutdown();
}