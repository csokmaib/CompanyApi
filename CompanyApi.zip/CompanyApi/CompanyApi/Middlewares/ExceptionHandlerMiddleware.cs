﻿using NLog;

namespace CompanyApi.Middlewares
{
    public class ExceptionHandlerMiddleware
    {
        private readonly Logger _logger;
        private readonly RequestDelegate _next;

        public ExceptionHandlerMiddleware(RequestDelegate next)
        {
            _logger = LogManager.GetCurrentClassLogger();
            _next = next;
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next.Invoke(context);
            }
            catch (Exception ex)
            {
                _logger.Error($"Error occured on path: {context.Request.Path.Value}");
                _logger.Error($"QueryString on path: {context.Request.QueryString}");
                _logger.Error(ex, ex.Message);
            }
        }
    }
}
