﻿using CompanyClasses;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace CompanyDataAccess
{
    public class MsSqlDataAccess
    {
        protected string ConnectionString { get; set; }

        public MsSqlDataAccess()
        {
        }

        public MsSqlDataAccess(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        private SqlConnection GetConnection()
        {
            SqlConnection connection = new SqlConnection(this.ConnectionString);
            if (connection.State != ConnectionState.Open)
                connection.Open();
            return connection;
        }

        protected DbCommand GetCommand(DbConnection connection, string commandText, CommandType commandType)
        {
            SqlCommand command = new SqlCommand(commandText, connection as SqlConnection);
            command.CommandType = commandType;
            return command;
        }

        protected SqlParameter GetParameter(string parameter, object value)
        {
            SqlParameter parameterObject = new SqlParameter(parameter, value != null ? value : DBNull.Value);
            parameterObject.Direction = ParameterDirection.Input;
            return parameterObject;
        }

        protected SqlParameter GetParameterOut(string parameter, SqlDbType type, object value = null, ParameterDirection parameterDirection = ParameterDirection.InputOutput)
        {
            SqlParameter parameterObject = new SqlParameter(parameter, type); ;

            if (type == SqlDbType.NVarChar || type == SqlDbType.VarChar || type == SqlDbType.NText || type == SqlDbType.Text)
            {
                parameterObject.Size = -1;
            }

            parameterObject.Direction = parameterDirection;

            if (value != null)
            {
                parameterObject.Value = value;
            }
            else
            {
                parameterObject.Value = DBNull.Value;
            }

            return parameterObject;
        }

        protected int ExecuteNonQuery(string procedureName, List<SqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            int returnValue = -1;

            try
            {
                using (SqlConnection connection = this.GetConnection())
                {
                    DbCommand cmd = this.GetCommand(connection, procedureName, commandType);

                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }

                    returnValue = cmd.ExecuteNonQuery();
                }
            }
            catch
            {
                //LogException("Failed to ExecuteNonQuery for " + procedureName, ex, parameters);
                throw;
            }

            return returnValue;
        }

        protected object ExecuteScalar(string procedureName, List<SqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            object returnValue = null;

            try
            {
                using (DbConnection connection = this.GetConnection())
                {
                    DbCommand cmd = this.GetCommand(connection, procedureName, commandType);

                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }

                    returnValue = cmd.ExecuteScalar();
                }
            }
            catch
            {
                //LogException("Failed to ExecuteScalar for " + procedureName, ex, parameters);
                throw;
            }

            return returnValue;
        }

        protected DbDataReader GetDataReader(string procedureName, List<SqlParameter> parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            DbDataReader ds;

            try
            {
                DbConnection connection = this.GetConnection();
                {
                    DbCommand cmd = this.GetCommand(connection, procedureName, commandType);
                    if (parameters != null && parameters.Count > 0)
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                    }

                    ds = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                }
            }
            catch
            {
                //LogException("Failed to GetDataReader for " + procedureName, ex, parameters);
                throw;
            }

            return ds;
        }

        public List<Company> GetCompanies()
        {
            List<Company> companyList = new List<Company>();
            string query = "SELECT * FROM Companies";
            using (DbDataReader dr = GetDataReader(query, null, CommandType.Text))
            {
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        companyList.Add(new Company
                        {
                            Id = Convert.ToInt32(dr["id"]),
                            Name = dr["name"].ToString() ?? string.Empty,
                            Exchange = dr["exchange"].ToString() ?? string.Empty,
                            Ticker = dr["ticker"].ToString() ?? string.Empty,
                            Isin = dr["isin"].ToString() ?? string.Empty,
                            WebSite = dr.IsDBNull("website") ? null : dr["website"].ToString()
                        });
                    }
                }
            }            
            return companyList;
        }

        public string AddCompany(Company company)
        {
            try
            {
                string query = "INSERT INTO Companies (name, exchange, ticker, isin, website) values (@name, @exchange, @ticker, @isin, @website); SELECT SCOPE_IDENTITY()";
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@name", company.Name));
                parameters.Add(new SqlParameter("@exchange", company.Exchange));
                parameters.Add(new SqlParameter("@ticker", company.Ticker));
                parameters.Add(new SqlParameter("@isin", company.Isin));
                parameters.Add(new SqlParameter("@website", company.WebSite));

                var result = ExecuteScalar(query, parameters, CommandType.Text);

                return result == null ? "Insert failed" : result.ToString();
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("UQ_isin"))
                    return "Isin already exists";
                return ex.Message;
            }
        }

        public Company GetCompanyByIsin(string isin)
        {
            Company company = new Company();
            string query = "SELECT * FROM Companies WHERE isin = @isin";
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@isin", isin));

            using (DbDataReader dr = GetDataReader(query, parameters, CommandType.Text))
            {
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        company = (new Company
                        {
                            Id = Convert.ToInt32(dr["id"]),
                            Name = dr["name"].ToString() ?? string.Empty,
                            Exchange = dr["exchange"].ToString() ?? string.Empty,
                            Ticker = dr["ticker"].ToString() ?? string.Empty,
                            Isin = dr["isin"].ToString() ?? string.Empty,
                            WebSite = dr.IsDBNull("website") ? null : dr["website"].ToString()
                        });
                    }
                }
            }
            return company;
        }

        public Company GetCompanyById(int companyId)
        {
            Company company = new Company();
            string query = "SELECT * FROM Companies WHERE id = @companyId";
            List<SqlParameter> parameters = new List<SqlParameter>();
            parameters.Add(new SqlParameter("@companyId", companyId));

            using (DbDataReader dr = GetDataReader(query, parameters, CommandType.Text))
            {
                if (dr != null && dr.HasRows)
                {
                    while (dr.Read())
                    {
                        company = (new Company
                        {
                            Id = Convert.ToInt32(dr["id"]),
                            Name = dr["name"].ToString() ?? string.Empty,
                            Exchange = dr["exchange"].ToString() ?? string.Empty,
                            Ticker = dr["ticker"].ToString() ?? string.Empty,
                            Isin = dr["isin"].ToString() ?? string.Empty,
                            WebSite = dr.IsDBNull("website") ? null : dr["website"].ToString()
                        });
                    }
                }
            }
            return company;
        }

        public (bool, string) UpdateCompany(Company company)
        {
            try
            {
                string query = "UPDATE Companies set name = @name, exchange = @exchange, ticker = @ticker, isin = @isin, website = @website WHERE id = @id";
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@id", company.Id));
                parameters.Add(new SqlParameter("@name", company.Name));
                parameters.Add(new SqlParameter("@exchange", company.Exchange));
                parameters.Add(new SqlParameter("@ticker", company.Ticker));
                parameters.Add(new SqlParameter("@isin", company.Isin));
                parameters.Add(new SqlParameter("@website", company.WebSite));

                var rowAffected = ExecuteNonQuery(query, parameters, CommandType.Text);

                return rowAffected > 0 ? (true, "Update successful") : (false, "Company doesn't exists");
            }
            catch (Exception ex)
            {
                if (ex.Message.Contains("UQ_isin"))
                    return (false, "Isin already exists");
                return (false, ex.Message);
            }
        }
    }
}