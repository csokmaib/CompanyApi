﻿using CompanyApi.Models;
using FluentValidation;

namespace CompanyApi.Validators
{
    public class CompanyInsertValidator : AbstractValidator<CompanyInsertDTO>
    {
        public CompanyInsertValidator()
        {
            RuleFor(x => x.Name).NotEmpty().NotNull().WithMessage("Company name is required")
                .Length(1,300).WithMessage("Company name should have max 300 lenght");
            RuleFor(x => x.Exchange).NotEmpty().NotNull().WithMessage("Company exchange is required")
                .Length(1, 100).WithMessage("Company exchange should have max 100 lenght");
            RuleFor(x => x.Ticker).NotEmpty().NotNull().WithMessage("Company ticker is required")
                .Length(1, 10).WithMessage("Company ticker should have max 10 lenght");
            RuleFor(x => x.Isin).NotEmpty().NotNull().WithMessage("Company isin is required")
                .Length(1, 12).WithMessage("Company isin should have max 12 lenght")
                .Matches("^[A-Z]{0,2}[0-9]{0,10}$").WithMessage("Company isin should start with 2 chars then 10 digits");
        }
    }

    public class CompanyUpdatetValidator : AbstractValidator<CompanyUpdateDTO>
    {
        public CompanyUpdatetValidator()
        {
            RuleFor(x => x.Id).GreaterThan(0).WithMessage("Company id is required");
            RuleFor(x => x.Name).NotEmpty().NotNull().WithMessage("Company name is required")
                .Length(1, 300).WithMessage("Company name should have max 300 lenght");
            RuleFor(x => x.Exchange).NotEmpty().NotNull().WithMessage("Company exchange is required")
                .Length(1, 100).WithMessage("Company exchange should have max 100 lenght");
            RuleFor(x => x.Ticker).NotEmpty().NotNull().WithMessage("Company ticker is required")
                .Length(1, 10).WithMessage("Company ticker should have max 10 lenght");
            RuleFor(x => x.Isin).NotEmpty().NotNull().WithMessage("Company isin is required")
                .Length(1, 12).WithMessage("Company isin should have max 12 lenght")
                .Matches("^[A-Z]{0,2}[0-9]{0,10}$").WithMessage("Company isin should start with 2 chars then 10 digits");
        }
    }
}
