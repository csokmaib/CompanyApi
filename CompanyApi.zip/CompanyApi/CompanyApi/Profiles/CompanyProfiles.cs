﻿using AutoMapper;
using CompanyApi.Models;
using CompanyClasses;

namespace CompanyApi.Mappers
{
    public class CompanyProfile : Profile
    {
        public CompanyProfile()
        {
            //<source, destination>
            CreateMap<Company, CompanyInsertDTO>();
            CreateMap<CompanyInsertDTO, Company>()
                .ForMember(dest => dest.Id, opt => opt.MapFrom(source => 0));

            //<source, destination>
            CreateMap<Company, CompanyUpdateDTO>().ReverseMap();
        }
    }
}
