﻿namespace CompanyApi.Options
{
    public class DBConnectionOptions
    {
        public const string DBConnectionOptionsSection = "ConnectionStrings";

        public string MsSqlConnection { get; set; } = default!;
    }
}
