﻿USE [Companies]
GO

/****** Object:  Table [dbo].[Companies]    Script Date: 4/20/2023 8:50:45 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Companies](
	[name] [nvarchar](300) NOT NULL,
	[exchange] [nvarchar](100) NOT NULL,
	[ticker] [nvarchar](10) NOT NULL,
	[isin] [nvarchar](12) NOT NULL,
	[website] [nchar](500) NULL,
	[id] [int] IDENTITY(1,1) NOT NULL,
 CONSTRAINT [UQ_isin] UNIQUE NONCLUSTERED 
(
	[isin] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
