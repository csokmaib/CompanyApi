﻿using CompanyApi.DataAccess;
using CompanyClasses;

namespace CompanyApi.Services
{
    public class CompanyServices: ICompanyServices
    {
        private readonly IMsSqlDAL _msSqlDbAccess;

        public CompanyServices(IMsSqlDAL msSqlDbAccess)
        {
            _msSqlDbAccess = msSqlDbAccess;
        }

        public List<Company> GetCompanies()
        {
            //more BL for company list if necessary
            return _msSqlDbAccess.GetCompanies();
            
        }

        public string AddCompany(Company company)
        {
            //more BL for company if necessary
            return _msSqlDbAccess.AddCompany(company);
        }

        public Company GetCompanyByIsin(string isin)
        {
            //more BL for company if necessary
            return _msSqlDbAccess.GetCompanyByIsin(isin);           
        }

        public Company GetCompanyById(int id)
        {
            //more BL for company if necessary
            return _msSqlDbAccess.GetCompanyById(id);           
        }

        public (bool, string) UpdateCompany(Company company)
        {
            //more BL for company if necessary
            return _msSqlDbAccess.UpdateCompany(company);           
        }
    }
}
