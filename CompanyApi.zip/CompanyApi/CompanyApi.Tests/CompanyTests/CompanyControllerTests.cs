﻿using AutoMapper;
using CompanyApi.Controllers;
using CompanyApi.DataAccess;
using CompanyApi.Models;
using CompanyApi.Services;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;

namespace CompanyApi.Tests.CompanyTests
{
    [TestFixture]
    public class CompanyControllerTests
    {
        private readonly Mock<IMapper> _mapper;
        private readonly Mock<IMsSqlDAL> _msSqlDbAccess;

        public CompanyControllerTests()
        {
            _mapper = new Mock<IMapper>();
            _msSqlDbAccess = new Mock<IMsSqlDAL>();
        }

        private CompanyServices GetCompanyService() => new(_msSqlDbAccess.Object);

        [Test]
        public void GetCompanyByIsin_IsinIsNull_ReturnBadRequestObjectResult()
        {
            var controller = new CompanyController(this.GetCompanyService(), _mapper.Object);
            var result = controller.GetCompanyByIsin("");
            Assert.That(result, Is.TypeOf<BadRequestObjectResult>());
        }

        [Test]
        public void GetCompanyByIsin_IsinHasValue_ReturnOkObjectResult()
        {
            var controller = new CompanyController(this.GetCompanyService(), _mapper.Object);
            var result = controller.GetCompanyByIsin("US0378331005");
            Assert.That(result, Is.TypeOf<OkObjectResult>());
        }

        [Test]
        public void AddCompany_NameIsNull_ReturnBadRequestObjectResult()
        {
            var controller = new CompanyController(this.GetCompanyService(), _mapper.Object);
            CompanyInsertDTO company = new CompanyInsertDTO
            {
                Name = null,
                Exchange = "Exchange test",
                Ticker = "ABCD",
                Isin = "AB1234567890",
                WebSite = null
            };

            var result = controller.AddCompany(company);
            Assert.That(result, Is.TypeOf<BadRequestObjectResult>());
        }
    }
}
